var foundationRoutes = [{"name":"home","url":"/","path":"templates/home.html"}]; 
